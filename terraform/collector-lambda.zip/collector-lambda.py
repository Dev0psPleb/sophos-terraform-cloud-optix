import os
import logging
import requests
import gzip
import base64
import json

logger = logging.getLogger()
logger.setLevel(logging.INFO)

defaultValue = 'xxxx'
UUID = os.getenv('CUSTOMER_ID', defaultValue).strip()
DNS_PREFIX = os.getenv('DNS_PREFIX', defaultValue).strip()
DNS_PATH = os.getenv('DNS_PATH', defaultValue).strip()

def lambda_handler(event, context):
	if UUID == defaultValue or DNS_PREFIX == defaultValue or DNS_PATH == defaultValue:
		logger.error("Please check uuid, DNS_PREFIX and DNS_PATH in parameters")
		return

	accountId = context.invoked_function_arn.split(":")[4]

	url = 'https://' + DNS_PREFIX + '/httpcollector/v2/'+ DNS_PATH
	data = event['awslogs']['data']
	dataJson = json.loads(gzip.decompress(base64.b64decode(data)))
	log_events = [ x['message'] for x in dataJson['logEvents']]
	log_events_data = {'uuid': UUID, 'logGroup': dataJson['logGroup'],
					'logStream': dataJson['logStream'], 'events': log_events}

	headers = {"Content-Type":"application/json", "uuid": UUID, "accountId": accountId}
	r = requests.post(url, data=json.dumps(log_events_data), headers=headers)
	if r.status_code == requests.codes.ok :
		logger.info('send to EVO')
	else :
		logger.error(r.text)


if __name__ == '__main__':
    lambda_handler(None, None) 

